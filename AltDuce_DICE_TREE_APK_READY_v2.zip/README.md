# AltDuce DICE TREE — APK Build Ready

실제 rd2-wiki의 nodes.json / dice-tree.svg를 앱에서 불러오는 Android WebView 앱입니다.

## APK 만들기
1. 이 프로젝트를 GitHub repository에 업로드합니다.
2. Actions 탭에서 `Build AltDuce DICE TREE APK`를 실행합니다.
3. 작업 완료 후 Artifacts의 `AltDuce-DICE-TREE-APK`에서 `app-debug.apk`를 받습니다.

## 주의
트리 데이터는 최신 상태를 받기 위해 인터넷 연결이 필요합니다. 투자 상태는 Android WebView localStorage에 저장됩니다.
